<footer class="brand-footer p-3 bg-dark border-bottom-red-5px">
    <div class="container rounded-bottom p-0">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="text-holder p-4">
                    <span class="text-white">
                        Copyright &copy; 2020 <span class="font-weight-bold">
                            <a class="text-white" target="_blank" href="https://web.facebook.com/shuaib.admin" title="AhmedShuaib">(AhmedShuaib)</a>
                        </span> All rights reserved</span>
                </div>
            </div>
        </div>
    </div>
</footer>
