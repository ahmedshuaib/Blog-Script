<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SystemOptions extends Model
{
    protected  $table = 'system_options';
}
