<div class="select2-purple">
    <select class="select2" id="tags_selector" name="tags[]" multiple="multiple" data-placeholder="Select Tags" data-dropdown-css-class="select2-purple" style="width: 100%;">
    </select>
</div>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/inc/select/tag-component.blade.php ENDPATH**/ ?>