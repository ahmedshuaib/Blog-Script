<?php
    echo '<?xml version="1.0" encoding="UTF-8"?>';
?>

<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc><?php echo e(url('/')); ?></loc>
        <lastmod><?php echo e($time); ?></lastmod>
    </sitemap>

    <sitemap>
        <loc><?php echo e(route('sitemap.category')); ?></loc>
        <lastmod><?php echo e($time); ?></lastmod>
    </sitemap>

    <sitemap>
        <loc><?php echo e(route('sitemap.tags')); ?></loc>
        <lastmod><?php echo e($time); ?></lastmod>
    </sitemap>

    <sitemap>
        <loc><?php echo e(route('sitemap.post')); ?></loc>
        <lastmod><?php echo e($time); ?></lastmod>
    </sitemap>

    <sitemap>
        <loc><?php echo e(route('sitemap.firmware')); ?></loc>
        <lastmod><?php echo e($time); ?></lastmod>
    </sitemap>

    <sitemap>
        <loc><?php echo e(route('sitemap.pages')); ?></loc>
        <lastmod><?php echo e($time); ?></lastmod>
    </sitemap>




</sitemapindex>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/sitemap/index.blade.php ENDPATH**/ ?>