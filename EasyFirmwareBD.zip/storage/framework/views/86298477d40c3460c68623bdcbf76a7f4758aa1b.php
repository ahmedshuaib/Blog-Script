<?php $__env->startSection('page-header-title', 'All Firmwares'); ?>
<?php $__env->startSection('page-current-position', 'Firmwares'); ?>
<?php $__env->startSection('pageTitle', 'All Firmware'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">All Firmwares</h3>
            </div>
            <div class="card-body">
                <table id="posts-table" class="table table-hover table-striped">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php if(count($firmwares) > 0): ?>
                        <?php $__currentLoopData = $firmwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(__($post->id)); ?></td>
                                <td><?php echo e(__($post->title)); ?></td>
                                <td><?php echo __($post->description); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e($post->path()); ?>" target="_blank" class="btn btn-success"><i class="fas fa-eye"></i></a>
                                        <a href="<?php echo e(route('firmware.edit', __($post->id))); ?>" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                                        <a id="navbarDropdown" class="btn btn-danger dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                            <i class="fas fa-trash"></i>
                                        </a>

                                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                            <a class="dropdown-item" href="#" onclick="event.preventDefault();
                                                document.getElementById('delete-form-<?php echo e(__($post->id)); ?>').submit();">
                                                <?php echo e(__('Confirm Delete')); ?>

                                            </a>

                                            <form id="delete-form-<?php echo e(__($post->id)); ?>" action="<?php echo e(route('firmware.destroy', $post->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="hidden" name="_method" value="delete">
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(function () {
        $("#posts-table").DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/all-firmware.blade.php ENDPATH**/ ?>