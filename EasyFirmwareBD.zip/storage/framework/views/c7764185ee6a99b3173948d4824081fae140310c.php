<ul class="dropdown-menu">
    <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="<?php echo e(count($child->children) ? 'dropdown-submenu' : ''); ?>">

        <a class="dropdown-item <?php echo e(count($child->children) ? 'dropdown-toggle' : ''); ?>" href="<?php echo e($child->path()); ?>">

            <?php echo $child->icon; ?>

            <?php echo e(__($child->title)); ?>


        </a>

        <?php if(count($child->children) > 0): ?>
        <?php echo $__env->make('inc.child-menu', ['children' => $child->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/inc/child-menu.blade.php ENDPATH**/ ?>