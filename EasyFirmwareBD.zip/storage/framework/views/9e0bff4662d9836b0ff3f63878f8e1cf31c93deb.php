<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale() )); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="<?php echo e($default->meta_keywords); ?>" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="all,index,follow,snippet,archive,odp">
    <meta name="title" content=" <?php echo $__env->yieldContent('meta-title'); ?>" />
    <meta name="description" content="<?php echo $__env->yieldContent('meta-description'); ?>, <?php echo e($default->meta_description); ?>" />
    <title><?php echo $__env->yieldContent('pageTitle'); ?>-<?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/png" sizes="192x192" href="/android-icon-192x192.png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/navy.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href=<?php echo e(asset('css/all.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('css/fontawesome.css')); ?>>
</head>

<body>
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src=<?php echo e(asset("plugins/jquery/jquery.min.js")); ?>></script>
    <script src=<?php echo e(asset("plugins/bootstrap/js/bootstrap.bundle.min.js")); ?>></script>
    <?php echo $__env->yieldContent('script'); ?>

    <script>
        $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
            if (!$(this).next().hasClass('show')) {
                $(this).parents('.dropdown-menu').first().find('.show').removeClass('show');
            }
            var $subMenu = $(this).next('.dropdown-menu');
            $subMenu.toggleClass('show');


            $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
                $('.dropdown-submenu .show').removeClass('show');
            });


            return false;
        });
    </script>
</body>

</html>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/layouts/master.blade.php ENDPATH**/ ?>