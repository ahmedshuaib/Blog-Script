<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale() )); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('pageTitle'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href=<?php echo e(asset("plugins/fontawesome-free/css/all.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/icheck-bootstrap/icheck-bootstrap.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/jqvmap/jqvmap.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("dist/css/master.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("dist/css/style.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/datatables-bs4/css/dataTables.bootstrap4.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/select2/css/select2.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/overlayScrollbars/css/OverlayScrollbars.min.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/daterangepicker/daterangepicker.css")); ?>>
    <link rel="stylesheet" href=<?php echo e(asset("plugins/summernote/summernote-bs4.css")); ?>>
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php echo $__env->make('dashboard.inc.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <?php echo $__env->make('dashboard.inc.page-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="content">
            <div class="container-fluid">
                <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </div>
    <?php echo $__env->make('dashboard.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<script src=<?php echo e(asset("plugins/jquery/jquery.min.js")); ?>></script>
<script src=<?php echo e(asset("plugins/jquery-ui/jquery-ui.min.js")); ?>></script>
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<script src=<?php echo e(asset("plugins/bootstrap/js/bootstrap.bundle.min.js")); ?>></script>
<script src=<?php echo e(asset("plugins/select2/js/select2.full.min.js")); ?>></script>

<script src=<?php echo e(asset("plugins/chart.js/Chart.min.js")); ?>></script>
<script src=<?php echo e(asset("plugins/sparklines/sparkline.js")); ?>></script>
<script src=<?php echo e(asset("plugins/jqvmap/jquery.vmap.min.js")); ?>></script>
<script src=<?php echo e(asset("plugins/jqvmap/maps/jquery.vmap.usa.js")); ?>></script>
<script src=<?php echo e(asset("plugins/jquery-knob/jquery.knob.min.js")); ?>></script>
<script src=<?php echo e(asset("plugins/moment/moment.min.js")); ?>></script>
<script src=<?php echo e(asset("plugins/daterangepicker/daterangepicker.js")); ?>></script>
<script src=<?php echo e(asset("plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js")); ?>></script>
<script src=<?php echo e(asset("plugins/summernote/summernote-bs4.min.js")); ?>></script>
<script src=<?php echo e(asset("plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js")); ?>></script>
<script src=<?php echo e(asset("dist/js/adminlte.js")); ?>></script>
<script src=<?php echo e(asset("plugins/datatables/jquery.dataTables.js")); ?>></script>
<script src=<?php echo e(asset("plugins/datatables-bs4/js/dataTables.bootstrap4.js")); ?>></script>

<script src=<?php echo e(asset('js/blog-functions.js')); ?>></script>

<script>
    const url = window.location;
    $('ul.nav-sidebar a').removeClass('active').parent().siblings().removeClass('menu-open');
    $('ul.nav-sidebar a').filter(function () {
        return this.href == url;
    }).addClass('active').closest(".has-treeview").addClass('menu-open').find("> a").addClass('active');
</script>
<?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/layouts/app.blade.php ENDPATH**/ ?>