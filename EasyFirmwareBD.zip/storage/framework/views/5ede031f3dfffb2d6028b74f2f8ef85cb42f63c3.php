<?php $__env->startSection('pageTitle', 'All Firmwares'); ?>
<?php $__env->startSection('meta-title', 'All Firmwares Download List'); ?>
<?php $__env->startSection('meta-description', 'Download All Firmwares'); ?>
<?php $__env->startSection('content'); ?>
    <section class="mt-3">
        <div class="container p-0">
            <div class="row p-4">
                <div class="col-md-8 col-sm-12">

                    <?php if(count($firmwares) > 0): ?>
                    <div class="card-header border-bottom-red-5px mb-4 font-weight-bold mb-5">
                        Files
                    </div>
                        <?php $__currentLoopData = $firmwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="mt-4 mb-4">
                                <div class="row">
                                    <div class="col-md-3 col-sm-12">
                                        <a class="img-container" href="<?php echo e($file->path()); ?>">
                                            <img class="img-fluid" src="<?php echo e($file->thumbnail != 'noimage.png' ? '/storage/img/'.$file->thumbnail : asset('/storage/img/'.$default->default_thumbnail)); ?>" alt="<?php echo e($file->title); ?>">
                                        </a>                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <div class="card-title bg-white border-bottom">
                                            <a class="card-link text-dark font-weight-bold" href="<?php echo e($file->path()); ?>"><?php echo e(__($file->title)); ?></a>
                                        </div>

                                        <div class="card-text">
                                            <?php echo $file->description; ?>

                                        </div>

                                    </div>
                                </div>
                            </article>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <div class="mb-5">
                        <?php echo e($firmwares->links()); ?>

                    </div>

                </div>

                <?php echo $__env->make('inc.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $('.pagination').addClass(`justify-content-end`)
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/firmware.blade.php ENDPATH**/ ?>