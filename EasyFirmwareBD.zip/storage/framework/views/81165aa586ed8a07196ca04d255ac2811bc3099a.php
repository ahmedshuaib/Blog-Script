<?php $__env->startSection('pageTitle', 'Edit Category'); ?>
<?php $__env->startSection('page-header-title', 'Category'); ?>
<?php $__env->startSection('page-current-position', 'Categories'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 col-sm-12 col-xs-12">
        <form action="<?php echo e(route('category.update', $category->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card card-dark shadow-sm">
                <div class="card-header">
                    <h4 class="card-title">Edit Category</h4>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>

                <div class="card-body">

                    <div class="form-group">
                        <input type="text" name="icon" class="form-control" value="<?php echo e($category->icon); ?>" placeholder="Enter you icon code" id="icon">
                    </div>

                    <div class="form-group">
                        <input type="text" placeholder="Edit Category Title" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title" id="title" autofocus value="<?php echo e($category->title); ?>">
                    </div>
                    <div class="form-group">
                        <textarea style="min-height: 100px;" class="form-control" name="description" placeholder="Edit Category Description"><?php echo e($category->description); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="parent_id">Parent Category</label>
                        <?php if(count($categories) > 0): ?>
                        <select name="parent_id" class="form-control" id="parent_id">
                            <option>None</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e(($category->parent_id == $category->id) ? 'selected' : ''); ?>> <?php echo e($category->title); ?> </option>
                            <?php if($category->parent_id != null): ?>
                            <option value="<?php echo e(__($category->id)); ?>"><?php echo e(__('--'.$category->title)); ?></option>
                            <?php continue; ?>
                            <?php endif; ?>
                            <option value="<?php echo e(__($category->id)); ?> <?php echo e(($category->parent_id == $category->id) ? 'selected' : ''); ?>"><?php echo e(__($category->title)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm float-right">Confirm update</button>
                </div>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function() {
        $("#cate-table").DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/edit-category.blade.php ENDPATH**/ ?>