<header>
    <?php if(auth()->guard()->check()): ?>
    <nav class="navbar navbar-expand-lg navbar-dark border-bottom-red-5px bg-primary">
        <div class="container">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.dash')); ?>">
                            <i class="fas fa-tachometer-alt"></i> <?php echo e(__('Dashboard')); ?>

                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php endif; ?>




    <div class="brand-text brand-header bg-dark border-bottom-red-5px">
        <div class="container p-1">
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <a href="/">
                        <h2 class="text-success mt-5 border-5px-radius"><b class="ml-5"><i>Green</i> <span class="text-white">Light</span> <span class="text-red">TFM</span></b></h2>
                    </a>
                </div>

                <div class="col-md-7 d-none d-sm-block col-sm-6 col-xs-12 text-right ml-auto">
                    <img class="bkash-logo-holder" src="<?php echo e(asset('/storage/img/'.$default->favicon_icon)); ?>">
                    <p class="text-white"><?php echo e(__($default->account_number)); ?></p>
                </div>

            </div>

        </div>
    </div>
    <div class="border-bottom-red-5px">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-light">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarText">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>"><span class="fas fa-home"></span> <?php echo e(__('Home')); ?> <span class="sr-only">(current)</span></a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('firmware') ? 'active' : ''); ?>" href="<?php echo e(route('all.firmware')); ?>"><span class="fas fa-file-archive"></span> <?php echo e(__('Firmware')); ?></a>
                        </li>

                        <?php if(count($categories) > 0): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->parent_id == null): ?>
                        <li class="nav-item <?php echo e(count($category->children) > 0 ? 'dropdown' : ''); ?>">


                            <?php if(count($category->children)): ?>
                            <a class="nav-link <?php echo e(request()->is('firmware') ? 'active' : ''); ?> dropdown-toggle" href="#" data-toggle="dropdown" id="dropmenu<?php echo e(Str::slug($category->title)); ?>" aria-haspopup="true" aria-expanded="false">

                                <?php echo $category->icon; ?>

                                <?php echo e(__($category->title)); ?>

                            </a>
                            <?php else: ?>
                            <a class="nav-link <?php echo e(request()->is('firmware') ? 'active' : ''); ?>" href="<?php echo e($category->path()); ?>">

                                <?php echo $category->icon; ?>

                                <?php echo e(__($category->title)); ?>

                            </a>
                            <?php endif; ?>

                            <?php if(count($category->children)): ?>
                            <ul class="dropdown-menu" aria-labelledby="dropmenu<?php echo e(Str::slug($category->title)); ?>">

                                <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(count($ch->children) ? 'dropdown-submenu' : ''); ?>">

                                    <?php if(count($ch->children)): ?>
                                    <a class="dropdown-item dropdown-toggle" href="#">
                                        <?php echo $category->icon; ?>

                                        <?php echo e(__($category->title)); ?>

                                    </a>
                                    <?php echo $__env->make('inc.child-menu', ['children' => $ch->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php else: ?>
                                    <a class="dropdown-item" href="">
                                        <?php echo $category->icon; ?>

                                        <?php echo e(__($category->title)); ?>

                                    </a>
                                    <?php endif; ?>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php endif; ?>

                        </li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                        <?php if(count($pages) > 0): ?>
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('page/*') ? 'active' : ''); ?>" href="<?php echo e($page->path()); ?>"><?php echo __($page->title); ?> </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>"><span class="fas fa-phone"></span> <?php echo e(__('Contact')); ?></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</header>
<section class="bg-light p-2 border-bottom">
    <div class="container">

        <?php if(count($recent_firmwares) > 0): ?>
        <div class="rf-mq-container mq-container container row">
            <div class="col-md-2 col-sm-3 col-xs-2 text-right">
                <i class="fas fa-clock"></i>
                <span class="hidden-xs font-13 font-weight-bold">Recent Files</span>
            </div>

            <div class="col-md-10 col-sm-9 col-xs-10">
                <div class="marquee-set">
                    <div class="marquee-content">
                        <?php $__currentLoopData = $recent_firmwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firmware): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mq-file-item inline">
                            <a href="<?php echo e($firmware->path()); ?>"><?php echo e(__($firmware->title)); ?></a>
                            <span class="item_date item_detail">[ <?php echo e($firmware->created_at->diffForHumans()); ?> ]</span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>



        <?php if(count($file_views) > 0): ?>
        <div class="tf-mq-container mq-container container row">
            <div class="col-md-2 col-sm-3 col-xs-2 text-right">
                <i class="fas fa-bolt"></i>
                <span class="hidden-xs font-13 font-weight-bold">Top Views</span>
            </div>

            <div class="col-md-10 col-sm-9 col-xs-10">
                <div class="marquee-set">
                    <div class="marquee-content">
                        <?php $__currentLoopData = $file_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mq-file-item inline">
                            <a href="<?php echo e($file->path()); ?>"><?php echo e(__($file->title)); ?></a>

                            <span class="item_downloads item_detail">[ <?php echo e(__($file->total_views)); ?> Views ]</span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>

</section>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/inc/header.blade.php ENDPATH**/ ?>