<?php $__env->startSection('pageTitle', $firmware->title); ?>
<?php $__env->startSection('meta-title', $firmware->title); ?>
<?php $__env->startSection('meta-description', $firmware->description); ?>
<?php $__env->startSection('content'); ?>
    <section class="mt-3">
        <div class="container p-0">
            <div class="col-md-12 p-4 col-sm-12">
                <div class="card rounded-0 bg-white">

                    <div class="card-body">
                        <h4 class="card-title text-center"> <?php echo e(__($firmware->title)); ?>  </h4>
                        <?php if(count($firmware->tags()->pluck('title')) > 0): ?>
                            <div class="card-header bg-white border-0 text-center">
                                <?php $__currentLoopData = $firmware->tags()->pluck('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-primary badge-pill"><?php echo e(__($tag)); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <?php if($firmware->thumbnail != 'noimage.png'): ?>
                            <img src="<?php echo e(asset('/storage/img/'.$firmware->thumbnail)); ?>" class="img-thumbnail border-0" alt="">
                        <?php endif; ?>

                        <div class="card-text text-center">
                            <?php echo __($firmware->body); ?>

                        </div>


                        <div class="card-comments">
                            <table class="table">
                                <tbody>
                                <tr>
                                    <td class="font-weight-bold text-right">Date : </td>
                                    <td class="text-left text-muted"><?php echo e($firmware->created_at); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold text-right">Firmware Size : </td>
                                    <td class="text-left text-muted"><?php echo e(__($firmware->firmware_size)); ?>

                                    <span><?php echo e($firmware->data_type); ?></span>
                                    </td>
                                </tr>

                                </tbody>
                            </table>

                        </div>

                        <a class="btn btn-primary btn-block" target="_blank" href="<?php echo e($firmware->download_link); ?>"><i class="fas fa-download"></i> Download</a>

                    </div>


                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/show-firmware.blade.php ENDPATH**/ ?>