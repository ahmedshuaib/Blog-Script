<?php $__env->startSection('pageTitle', $post->title); ?>
<?php $__env->startSection('meta-title', $post->title); ?>
<?php $__env->startSection('meta-description', $post->title . ' #YouTube'); ?>
<?php $__env->startSection('content'); ?>
    <section class="mt-3">
        <div class="container p-0">
            <div class="row p-4">
                <div class="col-md-8 col-sm-12">
                    <div class="card bg-white border-0">
                        <h5 class="card-header rounded-0 bg-white border-bottom">
                                 <?php echo e(__($post->title)); ?>

                        </h5>
                        <?php if($post->thumbnail != 'noimage.png'): ?>
                            <img src="<?php echo e(asset('storage/img/' . $post->thumbnail)); ?>" class="img-thumbnail my-2 border-0 card-img-top" alt="<?php echo e($post->title); ?>">
                        <?php endif; ?>
                        <?php if(count($post->tags()->pluck('title')) > 0): ?>
                        <div class="card-header bg-gradient-blue">
                            <?php $__currentLoopData = $post->tags()->pluck('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-primary badge-pill"><?php echo e(__($tag)); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>

                        <div class="card-body">
                            <div class="card-text">
                                <?php echo $post->body; ?>

                            </div>
                        </div>
                    </div>
                </div>

                <?php echo $__env->make('inc.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/show-post.blade.php ENDPATH**/ ?>