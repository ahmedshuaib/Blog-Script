<select name="category" data-placeholder="Select Category" class="form-control" id="category_selector">
    <?php if(!empty($category)): ?>
    <option value="<?php echo e($category->id); ?>" selected="selected"><?php echo e($category->title); ?></option>
    <?php endif; ?>
</select>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/inc/select/category-component.blade.php ENDPATH**/ ?>