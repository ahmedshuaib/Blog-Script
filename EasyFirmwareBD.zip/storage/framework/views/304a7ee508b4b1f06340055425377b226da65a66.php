<?php $__env->startSection('pageTitle', 'Welcome to Green Light TFM'); ?>
<?php $__env->startSection('meta-title', 'Green Light TFM'); ?>
<?php $__env->startSection('meta-description', 'Welcome to Green Light TFM'); ?>
<?php $__env->startSection('content'); ?>
    <section class="mt-3">
        <div class="container p-0">
            <div class="row p-4">
                <div class="col-md-8 col-sm-12">

                    <?php if(count($firmwares) > 0): ?>
                        <div class="card-header border-0 border-bottom-red-5px mb-4 font-weight-bold mb-5">
                            Latest Firmware
                        </div>
                        <?php $__currentLoopData = $firmwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="mt-4 mb-4">
                                <div class="row">
                                    <div class="col-md-3 col-sm-12">
                                        <a class="img-container" href="<?php echo e($file->path()); ?>">
                                            <img class="img-fluid" src="<?php echo e($file->thumbnail != 'noimage.png' ? '/storage/img/'.$file->thumbnail : asset('/storage/img/'.$default->default_thumbnail)); ?>" alt="<?php echo e($file->title); ?>">
                                        </a>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <div class="card-title bg-white border-bottom">
                                            <a class="card-link text-dark font-weight-bold" href="<?php echo e($file->path()); ?>"><?php echo e(__($file->title)); ?></a>
                                        </div>

                                        <div class="card-text">
                                            <?php echo $file->description; ?>

                                            <a href="<?php echo e($file->path()); ?>">[Read more...]</a>
                                        </div>

                                    </div>
                                </div>
                            </article>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($firmwares->links()); ?>

                    <?php endif; ?>

                    <?php if(count($posts) > 0): ?>
                            <div class="card-header rounded-0 border-bottom-red-5px mb-4 font-weight-bold">
                                Latest Posts
                            </div>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="mt-4 mb-4">
                                    <div class="row">
                                        <div class="col-md-3 col-sm-12">
                                            <img class="img-fluid" src="<?php echo e($post->thumbnail != 'noimage.png' ? asset('/storage/img/'.$post->thumbnail) : asset('/storage/img/'.$default->default_thumbnail)); ?>" alt="<?php echo e($post->title); ?>">
                                        </div>
                                        <div class="col-md-9 col-sm-12">

                                            <div class="card-title bg-white border-bottom">
                                                <a class="card-link text-dark font-weight-bold" href="<?php echo e($post->path()); ?>">
                                                    <?php echo e(__($post->title)); ?>

                                                </a>
                                            </div>

                                            <div class="card-comments">
                                                <?php if(count($post->tags()->pluck('title')) > 0): ?>
                                                    <?php $__currentLoopData = $post->tags()->pluck('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge badge-pill badge-primary">
                                                        <?php echo e(__($tag)); ?>

                                                    </span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                </article>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-5">
                                <?php echo e($posts->links()); ?>

                            </div>
                        <?php endif; ?>

                </div>

                <?php echo $__env->make('inc.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $('.pagination').addClass(`justify-content-end`)
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/index.blade.php ENDPATH**/ ?>