<div class="select2-purple">
    <select id="tags_selector" name="tags[]" multiple="multiple" data-placeholder="Select Tags" data-dropdown-css-class="select2-purple" style="width: 100%;">
        <?php if(count($tags) > 0): ?>
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tag->id); ?>" selected="selected"><?php echo e(__($tag->title)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/inc/select/edit-tag-component.blade.php ENDPATH**/ ?>