<footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="https://facebook.com/shuaib.admin" target="_blank">AhmedShuaib</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/inc/footer.blade.php ENDPATH**/ ?>