<?php $__env->startSection('pageTitle', 'Tag'); ?>
<?php $__env->startSection('page-header-title', 'Tags'); ?>
<?php $__env->startSection('page-current-position', 'Tags'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 col-sm-12 col-xs-12">
            <form action="<?php echo e(route('tags.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card card-dark shadow-sm">
                    <div class="card-header">
                        <h4 class="card-title">Add Tag</h4>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-tool" data-card-widget="remove">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <input type="text" placeholder="Add Tag Title" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title" id="title">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="description" placeholder="Add Tag Description" style="min-height: 100px;"></textarea>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-sm float-right"><i class="fas fa-save"></i> Save Tag</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-8 col-sm-12 col-xs-12">
            <div class="card card-dark">
                <div class="card-header">
                    <h4 class="card-title">All Tags</h4>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table id="cate-table" class="table table-hover table-striped">
                        <thead>
                        <tr>
                            <th>Id</th>
                            <th>Title</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(count($tags) > 0): ?>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(__($tag->id)); ?></td>
                                    <td><?php echo e(__($tag->title)); ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?php echo e(route('tags.edit', __($tag->id))); ?>" class="btn btn-info"><i class="fas fa-edit"></i></a>
                                            <a id="navbarDropdown" class="btn btn-danger dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                                <i class="fas fa-trash"></i>
                                            </a>

                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item" href="#" onclick="event.preventDefault();
                                                    document.getElementById('delete-form-<?php echo e(__($tag->id)); ?>').submit();">
                                                    <?php echo e(__('Confirm Delete')); ?>

                                                </a>

                                                <form id="delete-form-<?php echo e(__($tag->id)); ?>" action="<?php echo e(route('tags.destroy', $tag->id)); ?>" method="POST" style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="_method" value="delete">
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php endif; ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function () {
        $("#cate-table").DataTable();
    });
</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/add-tags.blade.php ENDPATH**/ ?>