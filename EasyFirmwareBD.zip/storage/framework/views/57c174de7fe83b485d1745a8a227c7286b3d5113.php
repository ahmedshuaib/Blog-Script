<?php $__env->startSection('script'); ?>
<script>
    $(function() {

        blog_render_select("#tags_selector", "<?php echo e(route('admin.select.tags')); ?>");
        blog_render_select("#category_selector", "<?php echo e(route('admin.select.categories')); ?>");


        $('#remove_thumb').click(function() {
            var is_checked = this.checked;
            var tag = $('.custom-file-input');
            var old_data = tag.attr('value');
            if (is_checked) {
                tag.attr('value', '');
            } else {
                tag.attr('value', "<?php echo e(!empty($thumbnail) ? $thumbnail : ''); ?>");
                console.log(tag.attr('value'));
            }
        });


        $('.textarea').summernote({
            height: 500
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/inc/select/select-js.blade.php ENDPATH**/ ?>