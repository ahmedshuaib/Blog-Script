<?php $__env->startSection('page-header-title', 'Pages'); ?>
<?php $__env->startSection('page-current-position', 'Pages'); ?>
<?php $__env->startSection('pageTitle', 'All Pages'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">All Pages</h3>
            </div>
            <div class="card-body">
                <table id="page-table" class="table table-hover table-striped">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(count($pages) > 0): ?>
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(__($page->id)); ?></td>
                                <td><?php echo e(__($page->title)); ?></td>
                                <td><?php echo e(__($page->description)); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('pages.show', $page->id)); ?>" class="btn btn-success"><i class="fas fa-eye"></i></a>
                                        <a href="<?php echo e(route('pages.edit', $page->id)); ?>" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                                        <a id="navbarDropdown" class="btn btn-danger dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                            <i class="fas fa-trash"></i>
                                        </a>

                                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                            <a class="dropdown-item" href="#" onclick="event.preventDefault();
                                document.getElementById('delete-form-<?php echo e(__($page->id)); ?>').submit();">
                                                <?php echo e(__('Confirm Delete')); ?>

                                            </a>

                                            <form id="delete-form-<?php echo e(__($page->id)); ?>" action="<?php echo e(route('pages.destroy', $page->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="_method" value="delete">
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $("#page-table").DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/dashboard/all-pages.blade.php ENDPATH**/ ?>