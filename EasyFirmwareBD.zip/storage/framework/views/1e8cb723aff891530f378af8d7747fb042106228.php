<?php $__env->startSection('pageTitle', $cat); ?>
<?php $__env->startSection('content'); ?>
    <section class="mt-3">
        <div class="container p-0">

            <div class="row p-4">
                <div class="col-md-8 col-sm-12">

                    <?php if(count($files) > 0): ?>
                        <div class="card-header shadow rounded-0 bg-success text-white mb-4 font-weight-bold">
                            Files
                        </div>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="mt-4 mb-4">
                                <div class="row">
                                    <div class="col-md-3 col-sm-12">
                                        <img class="img-fluid" src="<?php echo e($file->thumbnail != 'noimage.png' ? asset('/storage/img/'.$file->thumbnail) : asset('img/thumbnail.png')); ?>" alt="<?php echo e($file->title); ?>">
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <div class="card-title bg-white border-bottom">
                                            <a class="card-link text-dark font-weight-bold" href="<?php echo e($file->path()); ?>">
                                                <?php echo e(__($file->title)); ?>

                                            </a>
                                        </div>
                                        <div class="card-comments">
                                            <?php if(count($file->tags()->pluck('title')) > 0): ?>
                                                <?php $__currentLoopData = $file->tags()->pluck('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge badge-pill badge-primary">
                                                        <?php echo e(__($tag)); ?>

                                                    </span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>

                                    </div>
                                </div>
                            </article>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-5">
                            <?php echo e($files->links()); ?>

                        </div>
                    <?php endif; ?>



                    <?php if(count($posts) > 0): ?>
                        <div class="card-header shadow rounded-0 bg-success text-white mb-4 font-weight-bold">
                            Posts
                        </div>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="mt-4 mb-4">
                                <div class="row">
                                    <div class="col-md-3 col-sm-12">
                                        <img class="img-fluid" src="<?php echo e($file->thumbnail != 'noimage.png' ? asset('/storage/img/'.$file->thumbnail) : asset('img/thumbnail.png')); ?>" alt="<?php echo e($file->title); ?>">
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <div class="card-title bg-white border-bottom">
                                            <a class="card-link text-dark font-weight-bold" href="<?php echo e($file->path()); ?>">
                                                <?php echo e(__($file->title)); ?>

                                            </a>
                                        </div>
                                        <div class="card-comments">
                                            <?php if(count($file->tags()->pluck('title')) > 0): ?>
                                                <?php $__currentLoopData = $file->tags()->pluck('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge badge-pill badge-primary">
                                                        <?php echo e(__($tag)); ?>

                                                    </span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>

                                    </div>
                                </div>
                            </article>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($posts->links()); ?>

                    <?php endif; ?>


                </div>

                <?php echo $__env->make('inc.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $('.pagination').addClass(`justify-content-end`)
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/category.blade.php ENDPATH**/ ?>