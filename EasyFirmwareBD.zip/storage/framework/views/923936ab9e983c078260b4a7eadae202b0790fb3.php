<div class="col-md-4 col-sm-12">
    <form action="<?php echo e(route('search.keyword')); ?>" method="get">
        <div class="input-group mb-3">
                <input type="text" class="form-control" name="keyword" placeholder="Search...">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit"><i class="fas fa-search"></i></button>
                </div>
        </div>
    </form>



    <?php if(count($categories) > 0): ?>
        <div class="card-header border-0 font-weight-bold border-bottom-red-5px">
            <span class="card-title">Categories</span>
        </div>
        <ul class="list-group list-group-flush mb-3">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><a class="card-link" href="<?php echo e($category->path()); ?>"><?php echo __($category->title); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>


    <?php if(count($recent_posts) > 0): ?>
        <div class="card-header border-0 font-weight-bold border-bottom-red-5px">
            <span class="card-title">Recent posts</span>
        </div>
        <ul class="list-group list-group-flush mb-3">
            <?php $__currentLoopData = $recent_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><a class="card-link" href="<?php echo e($rpost->path()); ?>"><?php echo e(__($rpost->title)); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>


    <?php if(count($recent_firmwares) > 0): ?>
        <div class="card-header border-0 font-weight-bold border-bottom-red-5px">
            <span class="card-title">Recent Firmware</span>
        </div>
        <ul class="list-group list-group-flush">
            <?php $__currentLoopData = $recent_firmwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rfirm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><a class="card-link" href="<?php echo e($rfirm->path()); ?>"> <?php echo e(__($rfirm->title )); ?> </a> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

</div>
<?php /**PATH D:\WebDevelopment\EasyFirmwareBD\resources\views/inc/right-sidebar.blade.php ENDPATH**/ ?>